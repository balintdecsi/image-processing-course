function [decompressed_image] = lossless_decompress(compressed_image)
    
end