function [compressed] = lossy_compress(input_image, block_size, k)
    
end
