function [compressed_image] = lossless_compress(noncompressed_image)
    
end