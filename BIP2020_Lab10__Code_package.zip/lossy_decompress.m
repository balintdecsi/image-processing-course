function [decompressed] = lossy_decompress(compressed)
    
end
